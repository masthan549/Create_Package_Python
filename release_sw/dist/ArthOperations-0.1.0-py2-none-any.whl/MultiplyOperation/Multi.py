def MultiOp(x,y):
    return x*y