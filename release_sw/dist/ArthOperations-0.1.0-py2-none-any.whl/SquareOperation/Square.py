def SquareOp(x):
    return x*x